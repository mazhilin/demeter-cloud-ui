module.exports = {
	NODE_ENV: '"production"',
  ENV_CONFIG: '"dep"',
  BASE_API: '"https://www.shunyingxin.com/api/console/"'
}
