<template/>

<script>
export default {
  name: 'Manual'
}
</script>

<style scoped>

</style>
