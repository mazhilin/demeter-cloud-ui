<template/>

<script>
export default {
  name: 'Doument'
}
</script>

<style scoped>

</style>
