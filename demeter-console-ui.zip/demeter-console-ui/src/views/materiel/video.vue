<template/>

<script>
export default {
  name: 'Video'
}
</script>

<style scoped>

</style>
