<template/>

<script>
export default {
  name: 'Audio'
}
</script>

<style scoped>

</style>
