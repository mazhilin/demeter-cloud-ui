<template/>

<script>
export default {
  name: 'Picture'
}
</script>

<style scoped>

</style>
