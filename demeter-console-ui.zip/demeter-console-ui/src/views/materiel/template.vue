<template/>

<script>
export default {
  name: 'Template'
}
</script>

<style scoped>

</style>
