<template/>

<script>
export default {
  name: 'Tenant'
}
</script>

<style scoped>

</style>
