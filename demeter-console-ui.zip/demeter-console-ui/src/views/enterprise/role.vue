<template/>

<script>
export default {
  name: 'Role'
}
</script>

<style scoped>

</style>
