<template/>

<script>
export default {
  name: 'Interview'
}
</script>

<style scoped>

</style>
