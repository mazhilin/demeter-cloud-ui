<template/>

<script>
export default {
  name: 'Journal'
}
</script>

<style scoped>

</style>
